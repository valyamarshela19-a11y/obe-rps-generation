import { RPSData } from "../types";
import { Check, CircleCheck } from "lucide-react";

interface Props {
  data: RPSData;
}

export default function RPSPreview({ data }: Props) {
  const { courseInfo, cpls, cpmks, subCpmks, weeklyPlans } = data;

  return (
    <div id="rps-print-template" className="bg-white p-0 md:p-8 text-black font-calibri text-[11pt] leading-tight max-w-[210mm] mx-auto print:m-0 print:p-0 print:shadow-none shadow-xl border border-gray-100">
      {/* Header Table */}
      <table className="w-full border-collapse border-2 border-black mb-0 table-fixed">
        <tbody>
          <tr>
            <td className="border-2 border-black p-2 w-1/5 text-center">
              <img src="input_file_0.png" alt="Logo" className="w-16 h-16 mx-auto object-contain" referrerPolicy="no-referrer" />
              <p className="font-bold text-[7pt] mt-1 uppercase tracking-tighter leading-none">POLSA KUTOARJO</p>
            </td>
            <td className="border-2 border-black p-4 text-center w-3/5">
              <h1 className="text-lg font-bold uppercase">POLITEKNIK SAWUNGGALIH AJI</h1>
              <h3 className="text-lg font-bold uppercase">Program Studi {courseInfo.program}</h3>
            </td>
            <td className="border-2 border-black p-2 w-1/5 align-top text-[8pt]">
              <p className="font-bold">Kode Dokumen</p>
              <p className="mt-1 font-mono">{courseInfo.code}/RPS/{new Date().getFullYear()}</p>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Title Section */}
      <div className="bg-gray-100 border-x-2 border-b-2 border-black p-2 text-center">
        <h2 className="text-xl font-bold uppercase">RENCANA PEMBELAJARAN SEMESTER</h2>
      </div>

      {/* Metadata Table */}
      <table className="w-full border-collapse border-x-2 border-b-2 border-black text-[9pt] table-fixed">
        <tbody>
          <tr className="bg-gray-50 font-bold uppercase border-b border-black text-center align-middle h-8">
            <td className="border-r border-black p-1 w-1/4">MATA KULIAH (MK)</td>
            <td className="border-r border-black p-1 w-1/6">KODE</td>
            <td className="border-r border-black p-1 w-1/5">Rumpun MK</td>
            <td className="border-r border-black p-1 w-1/6 text-center">BOBOT (sks)</td>
            <td className="border-r border-black p-1 w-1/10 text-center">SEM</td>
            <td className="p-1 w-1/6">Tgl Penyusunan</td>
          </tr>
          <tr className="border-b-2 border-black h-12">
            <td className="border-r border-black p-2 font-bold text-center leading-tight">{courseInfo.name}</td>
            <td className="border-r border-black p-2 text-center">{courseInfo.code}</td>
            <td className="border-r border-black p-2 text-[8pt] text-center">{courseInfo.rumpunMK}</td>
            <td className="border-r border-black p-0">
              <div className="grid grid-cols-2 text-[7pt] h-full text-center divide-x divide-black">
                <div className="flex flex-col items-center justify-center p-1">
                  <span>T:{courseInfo.sksTeori}</span>
                </div>
                <div className="flex flex-col items-center justify-center p-1">
                  <span>P:{courseInfo.sksPraktek}</span>
                </div>
              </div>
            </td>
            <td className="border-r border-black p-2 text-center">{courseInfo.semester}</td>
            <td className="p-2 text-center">{new Date(courseInfo.datePrepared).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</td>
          </tr>
        </tbody>
      </table>

      {/* Auth Section */}
      <table className="w-full border-collapse border-x-2 border-b-2 border-black text-[9pt]">
        <tbody>
          <tr className="bg-white">
            <td className="border-r border-black p-1 font-bold w-1/4 align-top">OTORISASI</td>
            <td className="border-r border-black p-1 w-1/4 align-top">
              <p className="font-bold border-b border-black mb-8">Pengembang RPS</p>
              <div className="mt-auto pt-4 italic">
                <p className="font-bold uppercase underline">{courseInfo.pengembangRPS || courseInfo.lecturer}</p>
                <p className="text-[8pt] text-gray-600">NIDN/NUPTK: {courseInfo.lecturerNidn || '-'}</p>
              </div>
            </td>
            <td className="border-r border-black p-1 w-1/4 align-top">
              <p className="font-bold border-b border-black mb-8">Koordinator MK</p>
              <div className="mt-auto pt-4 italic">
                <p className="font-bold uppercase underline">{courseInfo.koordinatorRMK || courseInfo.lecturer}</p>
                <p className="text-[8pt] text-gray-600">NIDN/NUPTK: {courseInfo.lecturerNidn || '-'}</p>
              </div>
            </td>
            <td className="p-1 w-1/4 align-top">
                <p className="font-bold border-b border-black mb-8">Koordinator Program Studi</p>
                <div className="mt-auto pt-4 italic">
                  <p className="font-bold uppercase underline">{courseInfo.koordinatorProdi}</p>
                  <p className="text-[8pt] text-gray-600">NIDN/NUPTK: {courseInfo.koordinatorProdiNidn || '-'}</p>
                </div>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Model Section */}
      <table className="w-full border-collapse border-x-2 border-b-2 border-black text-[9pt]">
        <tbody>
          <tr>
            <td className="border-r border-black p-1 font-bold w-1/4">Model Pembelajaran</td>
            <td className="p-1">{courseInfo.modelPembelajaran}</td>
          </tr>
        </tbody>
      </table>

      {/* CPL & CPMK Section */}
      <div className="border-x-2 border-b-2 border-black text-[9pt]">
        <div className="bg-gray-50 border-b border-black p-1 font-bold">Capaian Pembelajaran (CP)</div>
        <table className="w-full border-collapse">
          <tbody>
            <tr>
              <td className="p-1 font-bold align-top w-1/4">CPL-PRODI yang dibebankan pada MK</td>
              <td className="p-1">
                <ul className="list-none space-y-1">
                  {cpls.map(cpl => (
                    <li key={cpl.id} className="flex gap-2">
                       <span className="font-bold w-12 shrink-0">{cpl.code}</span>
                       <span>{cpl.description}</span>
                    </li>
                  ))}
                </ul>
              </td>
            </tr>
            <tr className="border-t border-black">
              <td className="p-1 font-bold align-top w-1/4">Capaian Pembelajaran Mata Kuliah (CPMK)</td>
              <td className="p-1">
                <ul className="list-none space-y-1">
                  {cpmks.map(cpmk => (
                    <li key={cpmk.id} className="flex gap-2">
                       <span className="font-bold w-14 shrink-0">{cpmk.code}</span>
                       <span>{cpmk.description}</span>
                    </li>
                  ))}
                </ul>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Matrix CPL-CPMK */}
      <div className="border-x-2 border-b-2 border-black p-4">
        <p className="font-bold text-[9pt] mb-2 underline">Matrik CPL - CPMK</p>
        <div className="flex justify-center">
            <table className="border-collapse border border-black text-[8pt]">
                <thead>
                    <tr>
                        <th className="border border-black p-1 bg-gray-50">CPMK</th>
                        {cpls.map(cpl => (
                            <th key={cpl.id} className="border border-black p-1 bg-gray-50 w-10">{cpl.code}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {cpmks.map(cpmk => (
                        <tr key={cpmk.id}>
                            <td className="border border-black p-1 font-bold bg-gray-50">{cpmk.code}</td>
                            {cpls.map(cpl => (
                                <td key={cpl.id} className="border border-black p-1 text-center">
                                    {cpmk.mappedCPLIds.includes(cpl.id) ? "✓" : ""}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      </div>

      {/* Week Matrix */}
      <div className="border-x-2 border-b-2 border-black p-4">
         <p className="font-bold text-[9pt] mb-2 underline">Matrik CPMK pada Kemampuan akhir tiap tahapan belajar (Sub-CPMK)</p>
         <div className="flex justify-center overflow-x-auto">
            <table className="border-collapse border border-black text-[7pt]">
                <thead>
                    <tr>
                        <th rowSpan={2} className="border border-black p-1 bg-gray-50">CPMK</th>
                        <th colSpan={16} className="border border-black p-1 bg-gray-50">Minggu Ke</th>
                    </tr>
                    <tr>
                        {Array.from({ length: 16 }).map((_, i) => (
                            <th key={i} className="border border-black p-0.5 w-5 bg-gray-50">{i + 1}</th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {cpmks.map(cpmk => (
                        <tr key={cpmk.id}>
                            <td className="border border-black p-1 font-bold bg-gray-50">{cpmk.code}</td>
                            {weeklyPlans.map(plan => {
                                // Find if any sub-cpmk of this week is mapped to this cpmk
                                const isMapped = plan.subCPMKIds.some(subId => {
                                   const sub = subCpmks.find(s => s.id === subId);
                                   return sub?.mappedCPMKIds.includes(cpmk.id);
                                });
                                return (
                                    <td key={plan.week} className="border border-black p-0 text-center items-center justify-center">
                                        {isMapped ? "✓" : ""}
                                    </td>
                                );
                            })}
                        </tr>
                    ))}
                </tbody>
            </table>
         </div>
      </div>

      <div className="page-break" />

      {/* Description Section */}
      <table className="w-full border-collapse border-x-2 border-black text-[9pt]">
        <tbody>
          <tr className="border-b border-black">
            <td className="border-r border-black p-1 font-bold w-1/4 align-top bg-gray-50">Deskripsi Singkat MK</td>
            <td className="p-2 text-justify italic">{courseInfo.description}</td>
          </tr>
          <tr className="border-b border-black">
            <td rowSpan={2} className="border-r border-black p-1 font-bold w-1/4 align-top bg-gray-50">Pustaka</td>
            <td className="p-1 border-b border-black">
                <p className="font-bold underline text-[8pt]">Utama :</p>
                <ol className="list-decimal list-inside space-y-0.5 mt-1 ml-2">
                    {courseInfo.pustakaUtama.map((p, i) => <li key={i}>{p}</li>)}
                </ol>
            </td>
          </tr>
          <tr className="border-b border-black">
             <td className="p-1">
                <p className="font-bold underline text-[8pt]">Pendukung :</p>
                <ol className="list-decimal list-inside space-y-0.5 mt-1 ml-2">
                    {courseInfo.pustakaPendukung.length > 0 ? courseInfo.pustakaPendukung.map((p, i) => <li key={i}>{p}</li>) : <li className="text-gray-400">-</li>}
                </ol>
             </td>
          </tr>
          <tr className="border-b border-black">
            <td className="border-r border-black p-1 font-bold w-1/4 align-top bg-gray-50">Dosen Pengampu</td>
            <td className="p-2">
                <ul className="list-none space-y-0.5">
                    {courseInfo.dosenPengampu.length > 0 ? courseInfo.dosenPengampu.map((d, i) => <li key={i}>{d}</li>) : <li>{courseInfo.lecturer}</li>}
                </ul>
            </td>
          </tr>
        </tbody>
      </table>

      <div className="page-break" />

      {/* Main Weekly Detail Table */}
      <table className="w-full border-collapse border-2 border-black text-[7pt] mt-0">
        <thead className="bg-gray-100">
           <tr className="border-b-2 border-black">
             <th rowSpan={2} className="border-r border-black p-1 w-8">Mg Ke-</th>
             <th rowSpan={2} className="border-r border-black p-1 w-1/4">Kemampuan akhir tiap tahapan belajar (Sub-CPMK)</th>
             <th colSpan={2} className="border-r border-black p-1">Penilaian</th>
             <th colSpan={2} className="border-r border-black p-1">Bentuk Pembelajaran, Metode Pembelajaran, Penugasan Mahasiswa, [ Estimasi Waktu]</th>
             <th rowSpan={2} className="border-r border-black p-1 w-1/5">Materi Pembelajaran [ Pustaka ]</th>
             <th rowSpan={2} className="p-1 w-10">Bobot Penilaian (%)</th>
           </tr>
           <tr className="border-b-2 border-black">
             <th className="border-r border-black p-1">Indikator</th>
             <th className="border-r border-black p-1">Kriteria & Bentuk</th>
             <th className="border-r border-black p-1">Luring (offline)</th>
             <th className="border-r border-black p-1">Daring (online)</th>
           </tr>
           <tr className="border-b-2 border-black text-center font-bold">
              <td className="border-r border-black p-0.5">(1)</td>
              <td className="border-r border-black p-0.5">(2)</td>
              <td className="border-r border-black p-0.5">(3)</td>
              <td className="border-r border-black p-0.5">(4)</td>
              <td className="border-r border-black p-0.5">(5)</td>
              <td className="border-r border-black p-0.5">(6)</td>
              <td className="border-r border-black p-0.5">(7)</td>
              <td className="p-0.5">(8)</td>
           </tr>
        </thead>
        <tbody>
           {weeklyPlans.map((plan, idx) => (
             <tr key={idx} className={`border-b border-black align-top ${plan.week === 8 || plan.week === 16 ? "bg-gray-100 font-bold" : ""}`}>
                <td className="border-r border-black p-1 text-center font-bold">{plan.week}</td>
                <td className="border-r border-black p-1">
                   <ul className="list-disc list-inside space-y-1">
                        {plan.subCPMKIds.map(id => {
                            const sub = subCpmks.find(s => s.id === id);
                            return sub ? <li key={sub.id}>{sub.description}</li> : null;
                        })}
                   </ul>
                </td>
                <td className="border-r border-black p-1">{plan.assessmentIndicator}</td>
                <td className="border-r border-black p-1">{plan.assessmentCriteria}</td>
                <td className="border-r border-black p-1">
                    <p className="font-bold">{plan.method}</p>
                    <p>{plan.duration}</p>
                </td>
                <td className="border-r border-black p-1 text-center text-gray-400">-</td>
                <td className="border-r border-black p-1">
                   <p className="font-bold">Materi:</p>
                   <p>{plan.materials}</p>
                   {idx === 0 && courseInfo.pustakaUtama.length > 0 && (
                     <>
                        <p className="font-bold mt-2">Pustaka:</p>
                        <p className="italic text-[6pt]">{courseInfo.pustakaUtama[0]}</p>
                     </>
                   )}
                </td>
                <td className="p-1 text-center font-bold">{plan.weight}%</td>
             </tr>
           ))}
        </tbody>
      </table>

      {/* Assessment Section */}
      <div className="mt-8 border-2 border-black text-[9pt] max-w-lg">
        <div className="bg-gray-100 border-b-2 border-black p-2 font-bold text-center uppercase tracking-wider">Asesmen dan Penilaian</div>
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b border-black text-center font-bold">
              <th className="border-r border-black p-2 w-2/3 text-left">Komponen Penilaian</th>
              <th className="p-2 w-1/3">Bobot (%)</th>
            </tr>
          </thead>
          <tbody>
            {(data.assessmentComponents || []).map((comp, idx) => (
              <tr key={comp.id} className="border-b border-black">
                <td className="border-r border-black p-2">
                  <p className="font-bold">{comp.name}</p>
                  <p className="text-[8pt] italic text-gray-600">{comp.description}</p>
                </td>
                <td className="p-2 text-center font-bold">{comp.totalWeight}%</td>
              </tr>
            ))}
            <tr className="bg-gray-100 font-black">
               <td className="border-r border-black p-2 text-right uppercase tracking-widest px-4">Total Bobot</td>
               <td className="p-2 text-center">{(data.assessmentComponents || []).reduce((sum, c) => sum + c.totalWeight, 0)}%</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Signatures & Stamps Footer (Only visible if approved) */}
      {data.status === 'Disetujui' && (
        <div className="mt-8 relative h-64 border-2 border-black p-4 flex flex-col items-center justify-center">
           <p className="font-bold text-center">RPS ini telah divalidasi pada tanggal {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
           <div className="flex justify-around w-full mt-8">
              <div className="text-center">
                  <p className="font-bold text-[9pt] mb-4">Koordinator Program Studi {courseInfo.program}</p>
                  <div className="flex flex-col items-center">
                       <div className="mb-2">
                          <CircleCheck className="w-10 h-10 text-[#8bc34a]" fill="none" strokeWidth={3} />
                       </div>
                       <p className="font-bold underline">{courseInfo.koordinatorProdi}</p>
                       <p>NIDN/NUPTK: {courseInfo.koordinatorProdiNidn || '-'}</p>
                  </div>
              </div>
              <div className="text-center">
                  <p className="font-bold text-[9pt] mb-4">UPM Program Studi {courseInfo.program}</p>
                  <div className="flex flex-col items-center">
                       <div className="mb-2">
                          <CircleCheck className="w-10 h-10 text-[#8bc34a]" fill="none" strokeWidth={3} />
                       </div>
                       <p className="font-bold underline">Nama Koordinator UPM</p>
                       <p>NIDN/NUPTK/NIP: ......................</p>
                  </div>
              </div>
           </div>
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rotate-[-15deg] opacity-20 pointer-events-none">
               <div className="border-4 border-red-600 p-4 text-6xl font-black text-red-600 tracking-tighter">VALID</div>
           </div>
        </div>
      )}
      
      <p className="text-[7pt] text-center mt-4 italic text-gray-400">File PDF ini digenerate pada {new Date().toLocaleString('id-ID')} menggunakan aplikasi RPS-OBE Master Pro</p>
    </div>
  );
}
